
# Dead Rails Modelo - APK Release Automático

Este projeto contém:
- Jogo base estilo Dead Rails (2D).
- Workflow GitHub Actions para gerar **APK Release não assinado** automaticamente.

## Como usar
1. Crie um repositório no GitHub e envie todo o conteúdo deste projeto.
2. Vá na aba **Actions**, clique em **Build Godot Android APK Release** → **Run workflow**.
3. Espere a execução terminar. O APK estará disponível em **Artifacts → DeadRails-APK-Release**.

Este APK é **release não assinado**, você pode instalar em qualquer celular Android para testar.
